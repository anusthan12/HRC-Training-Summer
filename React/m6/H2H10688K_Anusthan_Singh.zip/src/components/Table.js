import React, { Component } from "react";
import "./table.css";
class Table extends Component {
  constructor(props) {
    super(props);

    this.state = {
      data: [
        {
          sl_no: 1,
          cust_order_id: 75434983,
          sales_org: 3911,
          dist: "United Arab Emirates",
          comp_code: 3290,
          creation: "01-01-2022",
          amount: 1405.54,
          order_curr: "AED",
          cust_number: "1210499770",
        },
        {
          sl_no: 2,
          cust_order_id: 930253442,
          sales_org: 2381,
          dist: "Greece",
          comp_code: 3290,
          creation: "01-01-2022",
          amount: 1441.4835,
          order_curr: "EUR",
          cust_number: "1210351400",
        },
        {
          sl_no: 3,
          cust_order_id: 819741436,
          sales_org: 3605,
          dist: "Argentina",
          comp_code: 3290,
          creation: "01-01-2022",
          amount: 1065.33,
          order_curr: "EUR",
          cust_number: "1210124309",
        },
        {
          sl_no: 4,
          cust_order_id: 881355361,
          sales_org: 3645,
          dist: "Armenia",
          comp_code: 3470,
          creation: "02-01-2022",
          amount: 302.85,
          order_curr: "EUR",
          cust_number: "12311152",
        },
        {
          sl_no: 5,
          cust_order_id: 821659852,
          sales_org: 2470,
          dist: "United States of America",
          comp_code: 3220,
          creation: "02-01-2022",
          amount: 8380.69,
          order_curr: "EUR",
          cust_number: "1230021722",
        },
        {
          sl_no: 6,
          cust_order_id: 957194828,
          sales_org: 3150,
          dist: "United States Minor Outlying Islands",
          comp_code: 3290,
          creation: "02-01-2022",
          amount: 545.85,
          order_curr: "EUR",
          cust_number: "1210183107",
        },
        {
          sl_no: 7,
          cust_order_id: 806322513,
          sales_org: 3396,
          dist: "Serbia",
          comp_code: 3290,
          creation: "02-01-2022",
          amount: 545.85,
          order_curr: "EUR",
          cust_number: "1210499770",
        },
        {
          sl_no: 8,
          cust_order_id: 922237131,
          sales_org: 2353,
          dist: "Turks and Caicos Islands",
          comp_code: 3290,
          creation: "02-01-2022",
          amount: 562.73,
          order_curr: "EUR",
          cust_number: "1210111951",
        },
      ],
    };
  }

  renderTableHeader() {
    return (
      <tr>
        <th>
          <input type="checkbox" name="name1" />
          Sl No
        </th>
        <th>CUSTOMER ORDER ID</th>
        <th>SALES ORG</th>
        <th>DISTRIBUTION CHANNEL</th>
        <th>COMPANY CODE</th>
        <th>ORDER CREATION DATE</th>
        <th>ORDER AMOUNT</th>
        <th>ORDER CURRENCY</th>
        <th>CUSTOMER NUMBER</th>
      </tr>
    );
  }

  renderTableData() {
    return this.state.data.map((row) => {
      const {
        sl_no,
        cust_order_id,
        sales_org,
        dist,
        comp_code,
        creation,
        amount,
        order_curr,
        cust_number,
      } = row;
      return (
        <React.Fragment key={sl_no}>
          <tr>
            <td>
              <input type="checkbox" name="name1" />
              {sl_no}
            </td>
            <td>{cust_order_id}</td>
            <td>{sales_org}</td>
            <td>{dist}</td>
            <td>{comp_code}</td>
            <td>{creation}</td>
            <td>{amount}</td>
            <td>{order_curr}</td>
            <td>{cust_number}</td>
          </tr>
        </React.Fragment>
      );
    });
  }

  render() {
    return (
      <table className="table">
        <thead>{this.renderTableHeader()}</thead>
        <tbody>{this.renderTableData()}</tbody>
      </table>
    );
  }
}

export default Table;
