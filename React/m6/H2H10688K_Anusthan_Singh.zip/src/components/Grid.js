import * as React from "react";
import { DataGrid } from "@mui/x-data-grid";
import { makeStyles } from '@mui/styles';

const useStyles = makeStyles(() => ({
  dataGridContainer: {
    height: "100vh",
    width: "100%",
    backgroundColor: "#5a5858",
    border: "8px solid #dd7b04",
    // overflow: "hidden",
  },
  dataGrid: {
    "& .MuiDataGrid-cell": {
      color: "white",
    },
    "& .header": {
      color: "white",
      whiteSpace: "normal",
      wordBreak: "break-word",
    },
    "& .MuiDataGrid-columnSeparator": {
      display: "none !important",
    },
    "& .MuiCheckbox-root": {
      color: "white",
    },
  },
}));

const columns = [
  {
    field: "id",
    headerName: "Sl No",
    // width: 67,
    width: 100,
    sortable: false,
    flex: 0.5,
    wrapText: true,
    headerClassName: "header",
  },
  {
    field: "cust_order_id",
    headerName: "CUSTOMER ORDER ID",
    // width: 187,
    width: 100,
    sortable: false,
    flex: 1,
    wrapText: true,
    headerClassName: "header",
  },
  {
    field: "sales_org",
    headerName: "SALES ORG",
    // width: 115,
    width: 100,
    sortable: false,
    flex: 1,
    wrapText: true,
    headerClassName: "header",
  },
  {
    field: "dist",
    headerName: "DISTRIBUTION CHANNEL",
    // width: 205,
    width: 100,
    sortable: false,
    flex: 1,
    wrapText: true,
    headerClassName: "header",
  },
  {
    field: "comp_code",
    headerName: "COMPANY CODE",
    // width: 148,
    width: 100,
    sortable: false,
    flex: 1,
    wrapText: true,
    headerClassName: "header",
  },
  {
    field: "creation",
    headerName: "ORDER CREATION DATE",
    // width: 201,
    width: 100,
    sortable: false,
    flex: 1,
    wrapText: true,
    headerClassName: "header",
  },
  {
    field: "amount",
    headerName: "ORDER AMOUNT",
    type: "number",
    // width: 149,
    width: 100,
    sortable: false,
    flex: 1,
    wrapText: true,
    headerClassName: "header",
  },
  {
    field: "order_curr",
    headerName: "ORDER CURRENCY",
    // width: 168,
    width: 100,
    sortable: false,
    flex: 1,
    wrapText: true,
    headerClassName: "header",
  },
  {
    field: "cust_number",
    headerName: "CUSTOMER NUMBER",
    // width: 179,
    width: 100,
    sortable: false,
    flex: 1,
    wrapText: true,
    headerClassName: "header",
  },
];

const rows = [
  {
    id: 1,
    cust_order_id: 75434983,
    sales_org: 3911,
    dist: "United Arab Emirates",
    comp_code: 3290,
    creation: "01-01-2022",
    amount: 1405.54,
    order_curr: "AED",
    cust_number: "1210499770",
  },
  {
    id: 2,
    cust_order_id: 930253442,
    sales_org: 2381,
    dist: "Greece",
    comp_code: 3290,
    creation: "01-01-2022",
    amount: 1441.4835,
    order_curr: "EUR",
    cust_number: "1210351400",
  },
  {
    id: 3,
    cust_order_id: 819741436,
    sales_org: 3605,
    dist: "Argentina",
    comp_code: 3290,
    creation: "01-01-2022",
    amount: 1065.33,
    order_curr: "EUR",
    cust_number: "1210124309",
  },
  {
    id: 4,
    cust_order_id: 881355361,
    sales_org: 3645,
    dist: "Armenia",
    comp_code: 3470,
    creation: "02-01-2022",
    amount: 302.85,
    order_curr: "EUR",
    cust_number: "12311152",
  },
  {
    id: 5,
    cust_order_id: 821659852,
    sales_org: 2470,
    dist: "United States of America",
    comp_code: 3220,
    creation: "02-01-2022",
    amount: 8380.69,
    order_curr: "EUR",
    cust_number: "1230021722",
  },
  {
    id: 6,
    cust_order_id: 957194828,
    sales_org: 3150,
    dist: "United States Minor Outlying Islands",
    comp_code: 3290,
    creation: "02-01-2022",
    amount: 545.85,
    order_curr: "EUR",
    cust_number: "1210183107",
  },
  {
    id: 7,
    cust_order_id: 806322513,
    sales_org: 3396,
    dist: "Serbia",
    comp_code: 3290,
    creation: "02-01-2022",
    amount: 545.85,
    order_curr: "EUR",
    cust_number: "1210499770",
  },
  {
    id: 8,
    cust_order_id: 922237131,
    sales_org: 2353,
    dist: "Turks and Caicos Islands",
    comp_code: 3290,
    creation: "02-01-2022",
    amount: 562.73,
    order_curr: "EUR",
    cust_number: "1210111951",
  },
];

export default function DataGridDemo() {
  const classes = useStyles();
  return (
    <div className={classes.dataGridContainer}>
      <DataGrid
        className={classes.dataGrid}
        disableColumnMenu
        hideFooter
        rows={rows}
        columns={columns}
        pageSize={8}
        checkboxSelection
        disableSelectionOnClick
      />
    </div>
  );
}
