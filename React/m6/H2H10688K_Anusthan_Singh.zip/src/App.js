import './App.css';
//import Table from './components/Table';
import Grid from './components/Grid'

function App() {
  return (
    <div className="App">
        <p>
          {/* <Table/>  */}
          <Grid/>
        </p>
    </div>
  );
}

export default App;